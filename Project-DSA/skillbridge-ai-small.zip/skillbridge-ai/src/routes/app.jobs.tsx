import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockJobRoles } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Briefcase, ChevronRight } from "lucide-react";

export const Route = createFileRoute("/app/jobs")({
  component: JobRolesPage,
});

function JobRolesPage() {
  const [search, setSearch] = useState("");

  const filteredRoles = mockJobRoles.filter(role => 
    role.title.toLowerCase().includes(search.toLowerCase()) || 
    role.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-6xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Job Roles</h2>
        <p className="text-muted-foreground">Explore career paths and see how your skills match up.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          className="pl-10 h-12 text-lg" 
          placeholder="Search for roles, e.g. Data Scientist..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredRoles.map((role, idx) => (
          <Card key={idx} className="flex flex-col h-full hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <Briefcase className="h-5 w-5 text-primary" />
                </div>
                <div className={`text-xs font-bold px-2 py-1 rounded-full ${
                  role.match >= 70 ? "bg-green-500/10 text-green-600" :
                  role.match >= 40 ? "bg-orange-500/10 text-orange-600" :
                  "bg-destructive/10 text-destructive"
                }`}>
                  {role.match}% Match
                </div>
              </div>
              <CardTitle className="text-xl">{role.title}</CardTitle>
              <CardDescription className="line-clamp-2">{role.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Required Skills</h4>
              <div className="flex flex-wrap gap-1.5">
                {role.requiredSkills.slice(0, 5).map(skill => (
                  <span key={skill} className="bg-secondary text-secondary-foreground text-[10px] px-2 py-1 rounded-sm">
                    {skill}
                  </span>
                ))}
                {role.requiredSkills.length > 5 && (
                  <span className="bg-muted text-muted-foreground text-[10px] px-2 py-1 rounded-sm">
                    +{role.requiredSkills.length - 5} more
                  </span>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Analyze My Profile <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
