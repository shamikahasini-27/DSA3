import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockMySkills } from "@/data/mock";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { BrainCircuit, Trash2, Edit2, Plus } from "lucide-react";

export const Route = createFileRoute("/app/my-skills")({
  component: MySkillsPage,
});

function MySkillsPage() {
  const [skills, setSkills] = useState(mockMySkills);
  const [newSkill, setNewSkill] = useState("");
  const [newLevel, setNewLevel] = useState("");

  const addSkill = () => {
    if (newSkill && newLevel) {
      setSkills([...skills, { name: newSkill, level: parseInt(newLevel) }]);
      setNewSkill("");
      setNewLevel("");
    }
  };

  const deleteSkill = (name: string) => {
    setSkills(skills.filter(s => s.name !== name));
  };

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">My Skills</h2>
          <p className="text-muted-foreground">Manage your current skillset and proficiency levels.</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-6 flex gap-4 items-end">
          <div className="flex-1">
            <label className="text-sm font-medium mb-1 block">Skill Name</label>
            <Input value={newSkill} onChange={e => setNewSkill(e.target.value)} placeholder="e.g. React" />
          </div>
          <div className="w-32">
            <label className="text-sm font-medium mb-1 block">Level (0-100)</label>
            <Input type="number" value={newLevel} onChange={e => setNewLevel(e.target.value)} placeholder="85" />
          </div>
          <Button onClick={addSkill}><Plus className="h-4 w-4 mr-2"/> Add Skill</Button>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {skills.map((skill, idx) => (
          <Card key={idx}>
            <CardContent className="p-5 flex flex-col justify-between h-full">
              <div>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <BrainCircuit className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">{skill.name}</h3>
                  </div>
                  <div className="flex gap-1">
                    <button className="text-muted-foreground hover:text-primary transition-colors">
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button onClick={() => deleteSkill(skill.name)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div className="flex justify-between text-xs mb-1 text-muted-foreground mt-4">
                  <span>Proficiency</span>
                  <span>{skill.level}%</span>
                </div>
                <Progress value={skill.level} className="h-2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
