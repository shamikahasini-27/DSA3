import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockResumeData } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { FileUp, CheckCircle2, XCircle, AlertCircle, Sparkles } from "lucide-react";

export const Route = createFileRoute("/app/resume")({
  component: ResumeAnalyzerPage,
});

function ResumeAnalyzerPage() {
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);

  const handleAnalyze = () => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      setAnalyzed(true);
    }, 2000);
  };

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Resume Analyzer</h2>
        <p className="text-muted-foreground">Upload your resume to get an ATS score and improvement suggestions.</p>
      </div>

      {!analyzed && (
        <Card className="border-dashed border-2 bg-muted/30">
          <CardContent className="flex flex-col items-center justify-center py-20 text-center">
            <div className="rounded-full bg-primary/10 p-4 mb-4">
              <FileUp className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Drag and drop your resume</h3>
            <p className="text-muted-foreground mb-6">Support for PDF, DOCX (Max 5MB)</p>
            <Button onClick={handleAnalyze} disabled={analyzing} size="lg">
              {analyzing ? "Analyzing with AI..." : "Upload & Analyze"}
            </Button>
          </CardContent>
        </Card>
      )}

      {analyzed && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-1 flex flex-col items-center justify-center py-8">
              <div className="relative flex items-center justify-center mb-4">
                <svg className="transform -rotate-90 w-32 h-32">
                  <circle cx="64" cy="64" r="54" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-muted/20" />
                  <circle cx="64" cy="64" r="54" stroke="currentColor" strokeWidth="12" fill="transparent" strokeDasharray={2 * Math.PI * 54} strokeDashoffset={(2 * Math.PI * 54) - (mockResumeData.atsScore / 100) * (2 * Math.PI * 54)} className="text-primary transition-all duration-1000 ease-out" />
                </svg>
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-3xl font-bold">{mockResumeData.atsScore}%</span>
                </div>
              </div>
              <h3 className="text-xl font-semibold">ATS Match Score</h3>
              <p className="text-sm text-muted-foreground mt-2 text-center px-4">Your resume is a good match, but missing some key terms.</p>
              <Button className="mt-6 w-3/4"><Sparkles className="h-4 w-4 mr-2"/> Auto-Improve</Button>
            </Card>

            <div className="md:col-span-2 grid gap-6 grid-cols-1 sm:grid-cols-2">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center"><CheckCircle2 className="h-4 w-4 mr-2 text-green-500" /> Detected Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {mockResumeData.detectedSkills.map(s => (
                      <span key={s} className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded-md">{s}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center"><XCircle className="h-4 w-4 mr-2 text-destructive" /> Missing Keywords</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {mockResumeData.missingKeywords.map(s => (
                      <span key={s} className="bg-destructive/10 text-destructive text-xs px-2 py-1 rounded-md">{s}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card className="sm:col-span-2">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-blue-500" /> Suggestions & Strengths</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Strengths</h4>
                    <ul className="space-y-1 text-sm list-disc list-inside">
                      {mockResumeData.strengths.map(s => <li key={s}>{s}</li>)}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Improvement Suggestions</h4>
                    <ul className="space-y-1 text-sm list-disc list-inside text-muted-foreground">
                      {mockResumeData.suggestions.map(s => <li key={s}>{s}</li>)}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
