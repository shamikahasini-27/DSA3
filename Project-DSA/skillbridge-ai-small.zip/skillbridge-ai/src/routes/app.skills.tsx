import { createFileRoute } from "@tanstack/react-router";
import { mockSkillGaps, mockUser } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Plus } from "lucide-react";

export const Route = createFileRoute("/app/skills")({
  component: SkillGapsPage,
});

function SkillGapsPage() {
  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Skill Gaps</h2>
          <p className="text-muted-foreground">Compare your skills against the {mockUser.targetRole} role requirements.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Add to Roadmap</Button>
          <Button>Generate Roadmap</Button>
        </div>
      </div>

      <div className="grid gap-6">
        {mockSkillGaps.map((gap, idx) => (
          <Card key={idx}>
            <CardHeader className="pb-3 flex flex-row items-start justify-between space-y-0">
              <div>
                <CardTitle className="text-lg">{gap.skill}</CardTitle>
                <CardDescription>
                  Current: {gap.current}% • Required: {gap.required}%
                </CardDescription>
              </div>
              <div className={`text-xs font-semibold px-2 py-1 rounded-full ${
                gap.priority === "High" ? "bg-destructive/10 text-destructive" :
                gap.priority === "Medium" ? "bg-orange-500/10 text-orange-500" :
                "bg-green-500/10 text-green-500"
              }`}>
                {gap.priority} Priority Gap
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1 text-muted-foreground">
                    <span>Your Level</span>
                    <span>{gap.current}%</span>
                  </div>
                  <Progress value={gap.current} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1 text-muted-foreground">
                    <span>Target Level</span>
                    <span>{gap.required}%</span>
                  </div>
                  <Progress value={gap.required} className="h-2 opacity-50 bg-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
