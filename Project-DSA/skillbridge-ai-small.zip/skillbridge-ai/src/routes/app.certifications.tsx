import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockCertifications } from "@/data/mock";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Award, Plus, Trash2, Edit2 } from "lucide-react";

export const Route = createFileRoute("/app/certifications")({
  component: CertificationsPage,
});

function CertificationsPage() {
  const [certs, setCerts] = useState(mockCertifications);

  const deleteCert = (id: number) => {
    setCerts(certs.filter(c => c.id !== id));
  };

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Certifications</h2>
          <p className="text-muted-foreground">Manage your credentials and earned certificates.</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2"/> Add Certification</Button>
      </div>

      <div className="grid gap-4">
        {certs.map((cert) => (
          <Card key={cert.id}>
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <Award className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{cert.name}</h3>
                  <p className="text-muted-foreground text-sm">Issued by {cert.organization}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon">
                  <Edit2 className="h-4 w-4 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => deleteCert(cert.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
