import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockRoadmap } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Clock, CheckCircle2, Circle, ArrowRightCircle } from "lucide-react";

export const Route = createFileRoute("/app/roadmap")({
  component: CareerRoadmapPage,
});

function CareerRoadmapPage() {
  const [roadmap, setRoadmap] = useState(mockRoadmap);

  const toggleStatus = (id: number) => {
    setRoadmap(roadmap.map(item => {
      if (item.id === id) {
        const nextStatus = 
          item.status === "Not Started" ? "In Progress" : 
          item.status === "In Progress" ? "Completed" : "Not Started";
        return { ...item, status: nextStatus };
      }
      return item;
    }));
  };

  const completedCount = roadmap.filter(r => r.status === "Completed").length;
  const progressPercent = Math.round((completedCount / roadmap.length) * 100);

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Career Roadmap</h2>
        <p className="text-muted-foreground">Your personalized path to becoming Job Ready.</p>
      </div>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Overall Progress</p>
              <h3 className="text-2xl font-bold">{progressPercent}%</h3>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-muted-foreground">Tasks Completed</p>
              <h3 className="text-xl font-bold">{completedCount} / {roadmap.length}</h3>
            </div>
          </div>
          <Progress value={progressPercent} className="h-3" />
        </CardContent>
      </Card>

      <div className="relative border-l-2 border-muted ml-3 space-y-8 mt-8 pl-8 pb-8">
        {roadmap.map((item) => (
          <div key={item.id} className="relative">
            <button 
              onClick={() => toggleStatus(item.id)}
              className="absolute -left-[41px] top-1 bg-background rounded-full p-1 border-2 border-muted cursor-pointer hover:border-primary transition-colors"
            >
              {item.status === "Completed" ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : item.status === "In Progress" ? (
                <ArrowRightCircle className="h-5 w-5 text-blue-500" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground" />
              )}
            </button>
            <Card className={item.status === "Completed" ? "opacity-60" : ""}>
              <CardHeader className="pb-3 flex flex-row items-start justify-between space-y-0">
                <div>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                  <CardDescription className="mt-1">{item.description}</CardDescription>
                </div>
                <div className={`text-xs font-semibold px-2 py-1 rounded-full ${
                  item.priority === "High" ? "bg-destructive/10 text-destructive" :
                  item.priority === "Medium" ? "bg-orange-500/10 text-orange-500" :
                  "bg-green-500/10 text-green-500"
                }`}>
                  {item.priority} Priority
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center text-muted-foreground">
                    <Clock className="h-4 w-4 mr-1" />
                    ~{item.hours} hours
                  </div>
                  <div className={`font-medium ${
                    item.status === "Completed" ? "text-green-500" :
                    item.status === "In Progress" ? "text-blue-500" : "text-muted-foreground"
                  }`}>
                    {item.status}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
