import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BrainCircuit,
  Compass,
  FileText,
  Gauge,
  Map as MapIcon,
  Rocket,
  Target,
  UserRound,
} from "lucide-react";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SkillBridge AI — Build Skills. Bridge the Gap. Become Job Ready." },
      {
        name: "description",
        content:
          "SkillBridge AI analyzes your skills and resume, finds your skill gaps for a target career, builds a personalized roadmap and tracks your job readiness.",
      },
      { property: "og:title", content: "SkillBridge AI — Become Job Ready" },
      {
        property: "og:description",
        content:
          "Analyze your resume, uncover skill gaps and follow a personalized roadmap to your target tech role.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const workflow = [
  { icon: UserRound, label: "Profile" },
  { icon: BrainCircuit, label: "AI Analysis" },
  { icon: Target, label: "Skill Gaps" },
  { icon: MapIcon, label: "Career Roadmap" },
  { icon: Rocket, label: "Job Ready" },
];

const features = [
  {
    icon: Target,
    title: "Skill Gap Analysis",
    text: "Compare your current skill levels against what your target role actually demands, ranked by priority.",
  },
  {
    icon: FileText,
    title: "AI Resume Enhancement",
    text: "Get an ATS score, detected skills, missing keywords and concrete rewrite suggestions in seconds.",
  },
  {
    icon: MapIcon,
    title: "Personalized Roadmap",
    text: "A step-by-step learning path with estimated hours, priorities and progress you can track.",
  },
  {
    icon: Gauge,
    title: "Career Readiness Score",
    text: "One number that combines your skills, projects, resume and certifications against your goal.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Logo />
          <nav className="flex items-center gap-2">
            <Link
              to="/login"
              className="rounded-xl px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              Log in
            </Link>
            <Link
              to="/register"
              className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              Get Started
            </Link>
          </nav>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden">
          <div className="pointer-events-none absolute -top-32 left-1/2 size-[38rem] -translate-x-1/2 rounded-full bg-violet-soft blur-3xl" />
          <div className="relative mx-auto max-w-3xl px-5 py-20 text-center sm:py-28">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3.5 py-1.5 text-xs font-medium text-muted-foreground shadow-card">
              <BrainCircuit className="size-3.5 text-primary" />
              AI-powered career readiness for students
            </span>
            <h1 className="mt-6 text-4xl font-bold leading-[1.1] sm:text-6xl">
              Build Skills. <span className="text-gradient-brand">Bridge the Gap.</span>
              <br className="hidden sm:block" /> Become Job Ready.
            </h1>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              SkillBridge AI reads your resume, maps your skills against real job roles and gives you
              a personalized roadmap to your dream career — with a readiness score that keeps you
              honest.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                to="/register"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-card transition-transform hover:-translate-y-0.5"
              >
                Get Started <ArrowRight className="size-4" />
              </Link>
              <Link
                to="/app/jobs"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold transition-colors hover:bg-secondary"
              >
                <Compass className="size-4" /> Explore Careers
              </Link>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 pb-20">
          <div className="card-surface p-6 sm:p-8">
            <p className="text-center text-sm font-semibold text-muted-foreground">
              How SkillBridge AI works
            </p>
            <ol className="mt-6 flex flex-col items-stretch gap-3 md:flex-row md:items-center">
              {workflow.map((step, i) => (
                <li key={step.label} className="flex flex-1 items-center gap-3 md:flex-col md:gap-3">
                  <div className="flex flex-1 items-center gap-3 md:flex-col md:text-center">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-primary">
                      <step.icon className="size-5" />
                    </span>
                    <span className="text-sm font-semibold">{step.label}</span>
                  </div>
                  {i < workflow.length - 1 && (
                    <ArrowRight className="size-4 shrink-0 rotate-90 text-muted-foreground/50 md:rotate-0" />
                  )}
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-24">
          <h2 className="text-center text-2xl font-bold sm:text-3xl">
            Everything you need to get hired
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-center text-sm text-muted-foreground">
            Four focused tools that take you from "I think I'm ready" to knowing exactly where you
            stand.
          </p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <article key={f.title} className="card-surface card-hover p-6">
                <span className="flex size-11 items-center justify-center rounded-xl bg-violet-soft text-violet">
                  <f.icon className="size-5" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-24">
          <div className="card-surface flex flex-col items-center gap-5 p-10 text-center">
            <h2 className="max-w-lg text-2xl font-bold sm:text-3xl">
              See your career readiness score in under a minute
            </h2>
            <Link
              to="/app/dashboard"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5"
            >
              Open the demo dashboard <ArrowRight className="size-4" />
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-3 px-5 text-center text-sm text-muted-foreground">
          <Logo compact />
          <p>SkillBridge AI — Build Skills. Bridge the Gap. Become Job Ready.</p>
        </div>
      </footer>
    </div>
  );
}
