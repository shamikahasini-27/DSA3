import { Outlet, Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { createFileRoute } from "@tanstack/react-router";
import {
  LayoutDashboard,
  FileText,
  Target,
  Map,
  Briefcase,
  BrainCircuit,
  FolderGit2,
  Award,
  User,
  LogOut,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Logo } from "@/components/Logo";
import { mockUser } from "@/data/mock";

export const Route = createFileRoute("/app")({
  component: AppLayout,
});

const navItems = [
  { title: "Dashboard", url: "/app/dashboard", icon: LayoutDashboard },
  { title: "Resume Analyzer", url: "/app/resume", icon: FileText },
  { title: "Skill Gaps", url: "/app/skills", icon: Target },
  { title: "Career Roadmap", url: "/app/roadmap", icon: Map },
  { title: "Job Roles", url: "/app/jobs", icon: Briefcase },
  { title: "My Skills", url: "/app/my-skills", icon: BrainCircuit },
  { title: "Projects", url: "/app/projects", icon: FolderGit2 },
  { title: "Certifications", url: "/app/certifications", icon: Award },
  { title: "Profile", url: "/app/profile", icon: User },
];

function AppLayout() {
  const router = useRouterState();
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate({ to: "/" });
  };

  return (
    <SidebarProvider>
      <Sidebar variant="inset">
        <SidebarHeader className="h-16 flex items-center justify-center border-b border-sidebar-border">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <Logo compact />
          </Link>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {navItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={router.location.pathname.startsWith(item.url)}
                      tooltip={item.title}
                    >
                      <Link to={item.url}>
                        <item.icon />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="border-t border-sidebar-border p-4">
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9">
              <AvatarImage src={mockUser.avatarUrl} alt={mockUser.name} />
              <AvatarFallback>RK</AvatarFallback>
            </Avatar>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-sm font-medium leading-none truncate">{mockUser.name}</span>
              <span className="text-xs text-muted-foreground truncate mt-1">{mockUser.targetRole}</span>
            </div>
          </div>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset className="flex flex-col flex-1 min-h-screen">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 bg-background">
          <SidebarTrigger className="-ml-1" />
          <div className="flex-1" />
          <button
            onClick={handleLogout}
            className="inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </button>
        </header>
        <main className="flex-1 overflow-auto bg-muted/20">
          <Outlet />
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
