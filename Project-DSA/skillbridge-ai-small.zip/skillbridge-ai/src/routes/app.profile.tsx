import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockUser } from "@/data/mock";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Edit2, Save } from "lucide-react";

export const Route = createFileRoute("/app/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState(mockUser);

  const toggleEdit = () => {
    setIsEditing(!isEditing);
  };

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Profile</h2>
          <p className="text-muted-foreground">Manage your personal and academic information.</p>
        </div>
        <Button onClick={toggleEdit} variant={isEditing ? "default" : "outline"}>
          {isEditing ? <><Save className="h-4 w-4 mr-2"/> Save Changes</> : <><Edit2 className="h-4 w-4 mr-2"/> Edit Profile</>}
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={profile.avatarUrl} alt={profile.name} />
              <AvatarFallback className="text-2xl">RK</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-2xl">{profile.name}</CardTitle>
              <p className="text-muted-foreground">{profile.targetRole}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name</label>
              <Input 
                value={profile.name} 
                readOnly={!isEditing} 
                onChange={e => setProfile({...profile, name: e.target.value})}
                className={!isEditing ? "bg-muted/50 border-transparent" : ""}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <Input 
                value={profile.email} 
                readOnly={!isEditing} 
                onChange={e => setProfile({...profile, email: e.target.value})}
                className={!isEditing ? "bg-muted/50 border-transparent" : ""}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Education</label>
              <Input 
                value={profile.education} 
                readOnly={!isEditing} 
                onChange={e => setProfile({...profile, education: e.target.value})}
                className={!isEditing ? "bg-muted/50 border-transparent" : ""}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">CGPA</label>
              <Input 
                value={profile.cgpa} 
                readOnly={!isEditing} 
                onChange={e => setProfile({...profile, cgpa: e.target.value})}
                className={!isEditing ? "bg-muted/50 border-transparent" : ""}
              />
            </div>
            <div className="col-span-2 space-y-2">
              <label className="text-sm font-medium">Career Goal</label>
              <Input 
                value={profile.careerGoal} 
                readOnly={!isEditing} 
                onChange={e => setProfile({...profile, careerGoal: e.target.value})}
                className={!isEditing ? "bg-muted/50 border-transparent" : ""}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
