import { createFileRoute } from "@tanstack/react-router";
import {
  mockReadinessScore,
  mockTopSkillGaps,
  mockRoadmapProgress,
  mockNextSteps,
  mockUser,
} from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Target, BrainCircuit, FolderGit2, FileText, Award, Map, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/app/dashboard")({
  component: DashboardPage,
});

function CircularProgress({ value }: { value: number }) {
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (value / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center">
      <svg className="transform -rotate-90 w-32 h-32">
        <circle
          cx="64"
          cy="64"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          fill="transparent"
          className="text-muted/20"
        />
        <circle
          cx="64"
          cy="64"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="text-primary transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center text-center">
        <span className="text-3xl font-bold">{value}%</span>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon }: { title: string; value: number; icon: any }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}%</div>
        <Progress value={value} className="mt-2" />
      </CardContent>
    </Card>
  );
}

function DashboardPage() {
  return (
    <div className="flex-1 space-y-6 p-6 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            Target Career: <span className="font-semibold text-foreground">{mockUser.targetRole}</span>
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="col-span-2 lg:col-span-1">
          <CardHeader>
            <CardTitle>Career Readiness</CardTitle>
            <CardDescription>Your overall match for {mockUser.targetRole}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-4">
            <CircularProgress value={mockReadinessScore.overall} />
            <p className="mt-4 text-sm text-center text-muted-foreground">
              You are {mockReadinessScore.overall}% ready for your target role.
            </p>
          </CardContent>
        </Card>

        <div className="col-span-2 lg:col-span-3 grid gap-4 md:grid-cols-2">
          <MetricCard title="Skills Match" value={mockReadinessScore.skills} icon={BrainCircuit} />
          <MetricCard title="Projects Score" value={mockReadinessScore.projects} icon={FolderGit2} />
          <MetricCard title="Resume Strength" value={mockReadinessScore.resume} icon={FileText} />
          <MetricCard title="Certifications" value={mockReadinessScore.certifications} icon={Award} />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Top Skill Gaps
            </CardTitle>
            <CardDescription>Skills you need to develop for your target role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockTopSkillGaps.map((gap, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="font-medium">{gap.name}</div>
                  <div
                    className={`text-xs font-semibold px-2 py-1 rounded-full ${
                      gap.priority === "High"
                        ? "bg-destructive/10 text-destructive"
                        : "bg-orange-500/10 text-orange-500"
                    }`}
                  >
                    {gap.priority} Priority
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Map className="h-5 w-5" />
              Roadmap & Next Steps
            </CardTitle>
            <CardDescription>Progress on your personalized learning path</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Roadmap Progress</span>
                <span className="text-sm font-medium">{mockRoadmapProgress}%</span>
              </div>
              <Progress value={mockRoadmapProgress} />
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-semibold">Recommended Next Steps</h4>
              {mockNextSteps.map((step, i) => (
                <div key={i} className="flex items-start gap-2 text-sm">
                  <ArrowRight className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
