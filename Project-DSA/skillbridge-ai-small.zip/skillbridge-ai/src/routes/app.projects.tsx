import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockProjects } from "@/data/mock";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FolderGit2, Plus, Github, Trash2, Edit2 } from "lucide-react";

export const Route = createFileRoute("/app/projects")({
  component: ProjectsPage,
});

function ProjectsPage() {
  const [projects, setProjects] = useState(mockProjects);

  const deleteProject = (id: number) => {
    setProjects(projects.filter(p => p.id !== id));
  };

  return (
    <div className="flex-1 space-y-6 p-6 pt-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Projects</h2>
          <p className="text-muted-foreground">Showcase your practical experience and portfolio.</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2"/> Add Project</Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {projects.map((project) => (
          <Card key={project.id} className="flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <FolderGit2 className="h-5 w-5 text-primary" />
                </div>
                <div className="flex gap-2">
                  <button className="text-muted-foreground hover:text-primary transition-colors p-1">
                    <Edit2 className="h-4 w-4" />
                  </button>
                  <button onClick={() => deleteProject(project.id)} className="text-muted-foreground hover:text-destructive transition-colors p-1">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <CardTitle>{project.title}</CardTitle>
              <CardDescription>{project.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Technologies Used</h4>
              <div className="flex flex-wrap gap-2">
                {project.technologies.map(tech => (
                  <span key={tech} className="bg-secondary text-secondary-foreground text-[10px] px-2 py-1 rounded-sm">
                    {tech}
                  </span>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t p-4 bg-muted/20">
              <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                project.status === "Completed" ? "bg-green-500/10 text-green-600" :
                "bg-blue-500/10 text-blue-600"
              }`}>
                {project.status}
              </span>
              <Button variant="ghost" size="sm" asChild>
                <a href={project.github} target="_blank" rel="noreferrer">
                  <Github className="h-4 w-4 mr-2" /> View Code
                </a>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
