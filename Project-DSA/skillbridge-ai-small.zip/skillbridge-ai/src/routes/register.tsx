import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Logo } from "@/components/Logo";
import { fieldClass, labelClass } from "@/components/Modal";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create your account — SkillBridge AI" },
      {
        name: "description",
        content:
          "Create a SkillBridge AI account to analyze your resume, find skill gaps and follow a personalized career roadmap.",
      },
      { property: "og:title", content: "Create your account — SkillBridge AI" },
      {
        property: "og:description",
        content: "Analyze your resume, find skill gaps and follow a personalized career roadmap.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegisterPage,
});

const roles = [
  "Machine Learning Engineer",
  "Data Scientist",
  "Data Analyst",
  "Software Developer",
  "Frontend Developer",
  "Backend Developer",
  "Full Stack Developer",
  "Cloud Engineer",
  "Cybersecurity Analyst",
];

function RegisterPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "Rahul Kumar",
    email: "rahul.kumar@example.com",
    password: "demo1234",
    role: roles[0],
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = "Enter a valid email address.";
    if (form.password.length < 6) next.password = "Password must be at least 6 characters.";
    setErrors(next);
    if (Object.keys(next).length) return;
    toast.success("Account created — welcome to SkillBridge AI!");
    void navigate({ to: "/app/dashboard" });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-5 py-12">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex justify-center">
          <Logo />
        </Link>
        <div className="card-surface p-7">
          <h1 className="text-xl font-bold">Create your account</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Start bridging the gap to your target role.
          </p>
          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <div>
              <label className={labelClass} htmlFor="name">
                Full name
              </label>
              <input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className={fieldClass}
              />
              {errors.name && <p className="mt-1 text-xs text-destructive">{errors.name}</p>}
            </div>
            <div>
              <label className={labelClass} htmlFor="reg-email">
                Email
              </label>
              <input
                id="reg-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={fieldClass}
              />
              {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
            </div>
            <div>
              <label className={labelClass} htmlFor="reg-password">
                Password
              </label>
              <input
                id="reg-password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className={fieldClass}
              />
              {errors.password && (
                <p className="mt-1 text-xs text-destructive">{errors.password}</p>
              )}
            </div>
            <div>
              <label className={labelClass} htmlFor="reg-role">
                Target career
              </label>
              <select
                id="reg-role"
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className={fieldClass}
              >
                {roles.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="submit"
              className="h-10 w-full rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Create account
            </button>
          </form>
          <p className="mt-5 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="font-semibold text-primary hover:underline">
              Log in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
