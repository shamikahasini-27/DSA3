import { useEffect, useRef, useState } from "react";
import { Bot, Send, Sparkle, User, X } from "lucide-react";
import { askAssistant, suggestedQuestions } from "@/services/assistantService";
import { useAppState } from "@/context/AppStateContext";
import { cn } from "@/lib/utils";
import type { ChatMessage } from "@/types";

function renderContent(text: string) {
  return text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
    part.startsWith("**") && part.endsWith("**") ? (
      <strong key={i} className="font-semibold text-foreground">
        {part.slice(2, -2)}
      </strong>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

export function AssistantChat({ className }: { className?: string }) {
  const { profile } = useAppState();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `Hi ${profile.name.split(" ")[0]}! I'm your SkillBridge AI career assistant. I know your profile and your ${profile.targetRole} goal — ask me anything about your skills, roadmap or resume.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, thinking]);

  async function send(text: string) {
    const question = text.trim();
    if (!question || thinking) return;
    setInput("");
    setMessages((prev) => [
      ...prev,
      { id: `u${Date.now()}`, role: "user", content: question },
    ]);
    setThinking(true);
    const answer = await askAssistant(question);
    setThinking(false);
    setMessages((prev) => [...prev, { id: `a${Date.now()}`, role: "assistant", content: answer }]);
  }

  return (
    <div className={cn("flex min-h-0 flex-1 flex-col", className)}>
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={cn("flex gap-2.5", m.role === "user" ? "justify-end" : "justify-start")}
          >
            {m.role === "assistant" && (
              <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full bg-brand-soft text-primary">
                <Bot className="size-4" />
              </span>
            )}
            <div
              className={cn(
                "max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
                m.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground",
              )}
            >
              {renderContent(m.content)}
            </div>
            {m.role === "user" && (
              <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground">
                <User className="size-4" />
              </span>
            )}
          </div>
        ))}
        {thinking && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="flex size-8 items-center justify-center rounded-full bg-brand-soft text-primary">
              <Bot className="size-4" />
            </span>
            <span className="animate-pulse">Thinking…</span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="border-t border-border p-3">
        <div className="mb-2.5 flex flex-wrap gap-1.5">
          {suggestedQuestions.map((q) => (
            <button
              key={q}
              type="button"
              onClick={() => void send(q)}
              className="rounded-full border border-border bg-card px-2.5 py-1 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:bg-brand-soft hover:text-primary"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send(input);
          }}
          className="flex items-center gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your career path…"
            aria-label="Message the AI career assistant"
            className="h-10 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none transition-shadow focus:ring-2 focus:ring-ring/40"
          />
          <button
            type="submit"
            disabled={!input.trim() || thinking}
            className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
            aria-label="Send message"
          >
            <Send className="size-4" />
          </button>
        </form>
      </div>
    </div>
  );
}

export function FloatingAssistant() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? "Close AI assistant" : "Open AI assistant"}
        className="fixed bottom-5 right-5 z-50 flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lift transition-transform hover:scale-105 active:scale-95"
      >
        {open ? <X className="size-6" /> : <Sparkle className="size-6" />}
      </button>

      {open && (
        <div className="fixed bottom-24 right-5 z-50 flex h-[520px] w-[min(24rem,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-lift">
          <div className="flex items-center gap-2.5 border-b border-border px-4 py-3">
            <span className="flex size-9 items-center justify-center rounded-xl bg-brand-soft text-primary">
              <Bot className="size-4.5" />
            </span>
            <div>
              <p className="text-sm font-semibold">AI Career Assistant</p>
              <p className="text-xs text-muted-foreground">Personalized to your profile</p>
            </div>
          </div>
          <AssistantChat />
        </div>
      )}
    </>
  );
}
