import { Waypoints } from "lucide-react";
import { cn } from "@/lib/utils";

export function Logo({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-card">
        <Waypoints className="size-5" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[1.05rem] font-bold tracking-tight">
            SkillBridge <span className="text-gradient-brand">AI</span>
          </span>
          <span className="mt-1 text-[0.65rem] font-medium tracking-wide text-muted-foreground">
            Build. Bridge. Be Ready.
          </span>
        </span>
      )}
    </span>
  );
}
