import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { Priority } from "@/types";

export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-7 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {description && <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function ProgressBar({
  value,
  className,
  tone = "brand",
}: {
  value: number;
  className?: string;
  tone?: "brand" | "violet" | "success" | "warning" | "muted";
}) {
  const tones: Record<string, string> = {
    brand: "bg-primary",
    violet: "bg-violet",
    success: "bg-success",
    warning: "bg-warning",
    muted: "bg-muted-foreground/40",
  };
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-secondary", className)}>
      <div
        className={cn("h-full rounded-full transition-all duration-700", tones[tone])}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  const styles: Record<Priority, string> = {
    High: "bg-destructive/10 text-destructive",
    Medium: "bg-warning/15 text-warning",
    Low: "bg-success/12 text-success",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        styles[priority],
      )}
    >
      {priority}
    </span>
  );
}

export function SkillBadge({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-border bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground">
      {children}
    </span>
  );
}

export function StatCard({
  label,
  value,
  icon,
  tone = "brand",
  hint,
}: {
  label: string;
  value: number;
  icon: ReactNode;
  tone?: "brand" | "violet" | "success" | "warning";
  hint?: string;
}) {
  return (
    <div className="card-surface card-hover p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{label}</p>
          <p className="mt-1 text-2xl font-bold">{value}%</p>
        </div>
        <span
          className={cn(
            "flex size-10 shrink-0 items-center justify-center rounded-xl",
            tone === "violet"
              ? "bg-violet-soft text-violet"
              : tone === "success"
                ? "bg-success/12 text-success"
                : tone === "warning"
                  ? "bg-warning/15 text-warning"
                  : "bg-brand-soft text-primary",
          )}
        >
          {icon}
        </span>
      </div>
      <ProgressBar value={value} tone={tone} className="mt-4" />
      {hint && <p className="mt-2 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="card-surface flex flex-col items-center justify-center p-10 text-center">
      <p className="font-semibold">{title}</p>
      <p className="mt-1 text-sm text-muted-foreground">{description}</p>
    </div>
  );
}
