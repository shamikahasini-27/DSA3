import type {
  Certification,
  JobRole,
  Project,
  ReadinessMetrics,
  ResumeAnalysis,
  RoadmapStep,
  Skill,
  SkillGap,
  UserProfile,
} from "@/types";

export const mockUser: UserProfile = {
  name: "Rahul Kumar",
  email: "rahul.kumar@example.com",
  phone: "+91 98765 43210",
  location: "Bengaluru, India",
  targetRole: "Machine Learning Engineer",
  bio: "Final-year Computer Science student passionate about machine learning, data analysis and building practical AI projects.",
  education: {
    degree: "B.Tech, Computer Science & Engineering",
    institution: "National Institute of Technology",
    year: "2023 - 2027",
    cgpa: "8.6 / 10",
  },
};

export const mockReadiness: ReadinessMetrics = {
  overall: 72,
  skills: 70,
  projects: 80,
  resume: 78,
  certifications: 60,
  roleMatch: 72,
};

export const mockSkills: Skill[] = [
  { id: "s1", name: "Python", category: "Programming", proficiency: "Advanced", score: 85 },
  { id: "s2", name: "SQL", category: "Data", proficiency: "Intermediate", score: 70 },
  {
    id: "s3",
    name: "Machine Learning",
    category: "AI/ML",
    proficiency: "Intermediate",
    score: 65,
  },
  { id: "s4", name: "Pandas", category: "Data", proficiency: "Advanced", score: 80 },
  { id: "s5", name: "Scikit-learn", category: "AI/ML", proficiency: "Intermediate", score: 75 },
  { id: "s6", name: "Deep Learning", category: "AI/ML", proficiency: "Beginner", score: 25 },
  { id: "s7", name: "TensorFlow", category: "AI/ML", proficiency: "Beginner", score: 20 },
  { id: "s8", name: "Statistics", category: "Mathematics", proficiency: "Beginner", score: 40 },
  { id: "s9", name: "Docker", category: "DevOps", proficiency: "Beginner", score: 15 },
];

export const mockSkillGaps: SkillGap[] = [
  { skill: "Python", current: 85, required: 85, priority: "Low" },
  { skill: "SQL", current: 70, required: 75, priority: "Low" },
  { skill: "Machine Learning", current: 65, required: 85, priority: "Medium" },
  { skill: "Deep Learning", current: 25, required: 80, priority: "High" },
  { skill: "TensorFlow", current: 20, required: 75, priority: "High" },
  { skill: "Statistics", current: 40, required: 75, priority: "Medium" },
  { skill: "Docker", current: 15, required: 60, priority: "Medium" },
];

export const mockRoadmap: RoadmapStep[] = [
  {
    id: "r1",
    title: "Python",
    description: "Strengthen core Python, OOP and data structures for ML workflows.",
    status: "completed",
    priority: "High",
    estimatedHours: 40,
  },
  {
    id: "r2",
    title: "Machine Learning",
    description: "Supervised and unsupervised learning, model evaluation and tuning.",
    status: "completed",
    priority: "High",
    estimatedHours: 60,
  },
  {
    id: "r3",
    title: "Statistics",
    description: "Probability, distributions, hypothesis testing and inference.",
    status: "in-progress",
    priority: "Medium",
    estimatedHours: 35,
  },
  {
    id: "r4",
    title: "Deep Learning",
    description: "Neural networks, CNNs, RNNs, backpropagation and regularization.",
    status: "not-started",
    priority: "High",
    estimatedHours: 70,
  },
  {
    id: "r5",
    title: "TensorFlow",
    description: "Build, train and deploy models with TensorFlow and Keras.",
    status: "not-started",
    priority: "High",
    estimatedHours: 45,
  },
  {
    id: "r6",
    title: "ML Project",
    description: "End-to-end capstone project with data pipeline and deployment.",
    status: "not-started",
    priority: "High",
    estimatedHours: 80,
  },
  {
    id: "r7",
    title: "Resume Optimization",
    description: "Rewrite resume with ATS keywords, metrics and project impact.",
    status: "not-started",
    priority: "Medium",
    estimatedHours: 10,
  },
  {
    id: "r8",
    title: "Interview Preparation",
    description: "ML theory, coding rounds, case studies and mock interviews.",
    status: "not-started",
    priority: "Medium",
    estimatedHours: 50,
  },
];

export const mockJobRoles: JobRole[] = [
  {
    id: "j1",
    title: "Machine Learning Engineer",
    category: "AI/ML",
    match: 72,
    avgSalary: "₹12 - 22 LPA",
    demand: "Very High",
    description: "Design, train and deploy machine learning models into production systems.",
    requiredSkills: ["Python", "Machine Learning", "Deep Learning", "TensorFlow", "Docker", "Statistics"],
  },
  {
    id: "j2",
    title: "Data Scientist",
    category: "Data",
    match: 68,
    avgSalary: "₹10 - 20 LPA",
    demand: "Very High",
    description: "Turn raw data into insights and predictive models that drive decisions.",
    requiredSkills: ["Python", "Statistics", "SQL", "Machine Learning", "Pandas"],
  },
  {
    id: "j3",
    title: "Data Analyst",
    category: "Data",
    match: 81,
    avgSalary: "₹6 - 12 LPA",
    demand: "High",
    description: "Analyze datasets, build dashboards and report business metrics.",
    requiredSkills: ["SQL", "Excel", "Python", "Pandas", "Visualization"],
  },
  {
    id: "j4",
    title: "Software Developer",
    category: "Engineering",
    match: 64,
    avgSalary: "₹8 - 18 LPA",
    demand: "High",
    description: "Build and maintain reliable software across the application stack.",
    requiredSkills: ["Data Structures", "Algorithms", "Java", "Git", "Databases"],
  },
  {
    id: "j5",
    title: "Frontend Developer",
    category: "Engineering",
    match: 45,
    avgSalary: "₹6 - 15 LPA",
    demand: "High",
    description: "Craft responsive, accessible user interfaces for web products.",
    requiredSkills: ["HTML", "CSS", "JavaScript", "React", "TypeScript"],
  },
  {
    id: "j6",
    title: "Backend Developer",
    category: "Engineering",
    match: 55,
    avgSalary: "₹8 - 18 LPA",
    demand: "High",
    description: "Design APIs, services and data models that power applications.",
    requiredSkills: ["Python", "Node.js", "SQL", "REST APIs", "Docker"],
  },
  {
    id: "j7",
    title: "Full Stack Developer",
    category: "Engineering",
    match: 50,
    avgSalary: "₹9 - 20 LPA",
    demand: "Very High",
    description: "Own features end to end, from database to user interface.",
    requiredSkills: ["React", "Node.js", "SQL", "TypeScript", "Git"],
  },
  {
    id: "j8",
    title: "Cloud Engineer",
    category: "Infrastructure",
    match: 38,
    avgSalary: "₹10 - 22 LPA",
    demand: "High",
    description: "Build and operate scalable cloud infrastructure and pipelines.",
    requiredSkills: ["AWS", "Docker", "Kubernetes", "Linux", "Terraform"],
  },
  {
    id: "j9",
    title: "Cybersecurity Analyst",
    category: "Security",
    match: 32,
    avgSalary: "₹7 - 16 LPA",
    demand: "Moderate",
    description: "Monitor, detect and respond to security threats and vulnerabilities.",
    requiredSkills: ["Networking", "Linux", "SIEM", "Cryptography", "Python"],
  },
];

export const mockProjects: Project[] = [
  {
    id: "p1",
    title: "Student Performance Prediction",
    description:
      "Regression model predicting exam scores from study habits and demographics, with feature importance analysis.",
    technologies: ["Python", "Pandas", "Scikit-learn", "Matplotlib"],
    status: "Completed",
    githubUrl: "https://github.com/rahulkumar/student-performance",
  },
  {
    id: "p2",
    title: "Movie Recommendation System",
    description:
      "Content-based and collaborative filtering recommender built on the MovieLens dataset.",
    technologies: ["Python", "NumPy", "Scikit-learn", "Streamlit"],
    status: "Completed",
    githubUrl: "https://github.com/rahulkumar/movie-recommender",
  },
  {
    id: "p3",
    title: "Face Mask Detection",
    description:
      "Real-time mask detection using a convolutional neural network and OpenCV video capture.",
    technologies: ["Python", "OpenCV", "Keras", "CNN"],
    status: "In Progress",
    githubUrl: "https://github.com/rahulkumar/face-mask-detection",
  },
];

export const mockCertifications: Certification[] = [
  {
    id: "c1",
    title: "Machine Learning Fundamentals",
    issuer: "Coursera",
    issuedDate: "March 2025",
    credentialUrl: "https://coursera.org/verify/ml-fundamentals",
  },
  {
    id: "c2",
    title: "Python for Data Science",
    issuer: "IBM / edX",
    issuedDate: "November 2024",
    credentialUrl: "https://edx.org/verify/python-data-science",
  },
];

export const mockResumeAnalysis: ResumeAnalysis = {
  atsScore: 78,
  detectedSkills: ["Python", "SQL", "Machine Learning", "Pandas", "NumPy", "Scikit-learn"],
  missingKeywords: ["Deep Learning", "TensorFlow", "Docker", "Statistics"],
  strengths: [
    "Clear, single-column layout that parses well in ATS systems",
    "Strong project section with measurable outcomes",
    "Relevant coursework aligned with data and ML roles",
    "Concise one-page format",
  ],
  improvements: [
    "Add deep learning and TensorFlow experience to the skills section",
    "Quantify project results with accuracy, dataset size or impact",
    "Include a short professional summary targeting ML Engineer roles",
    "Add deployment keywords such as Docker, REST API and MLOps",
  ],
};

export const nextSteps: { title: string; detail: string; hours: number }[] = [
  {
    title: "Complete the Statistics module",
    detail: "You are mid-way through inference and hypothesis testing.",
    hours: 12,
  },
  {
    title: "Start Deep Learning fundamentals",
    detail: "Highest impact gap for the Machine Learning Engineer role.",
    hours: 70,
  },
  {
    title: "Add TensorFlow to a project",
    detail: "Rebuild your face mask detector with TensorFlow and Keras.",
    hours: 20,
  },
  {
    title: "Refresh your resume",
    detail: "Add four missing ATS keywords to reach an 88% score.",
    hours: 3,
  },
];
