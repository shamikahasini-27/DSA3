export const mockUser = {
  name: "Rahul Kumar",
  email: "rahul.kumar@example.com",
  targetRole: "Machine Learning Engineer",
  avatarUrl: "https://i.pravatar.cc/150?u=rahul",
  education: "B.Tech in Computer Science",
  cgpa: "8.5/10",
  careerGoal: "To become a Machine Learning Engineer focusing on deep learning and AI models.",
};

export const mockReadinessScore = {
  overall: 72,
  skills: 70,
  projects: 80,
  resume: 78,
  certifications: 60,
  targetMatch: 72,
};

export const mockTopSkillGaps = [
  { name: "Deep Learning", priority: "High" },
  { name: "TensorFlow", priority: "High" },
  { name: "Statistics", priority: "Medium" },
  { name: "Docker", priority: "Medium" },
];

export const mockRoadmapProgress = 45;

export const mockNextSteps = [
  "Complete 'Deep Learning Specialization' on Coursera",
  "Add a TensorFlow project to your portfolio",
  "Revise your resume to highlight Python and SQL experience",
];

export const mockResumeData = {
  atsScore: 78,
  detectedSkills: ["Python", "SQL", "Machine Learning", "Pandas", "Scikit-learn"],
  missingKeywords: ["Deep Learning", "TensorFlow", "Statistics", "Docker", "PyTorch"],
  strengths: ["Strong academic background", "Relevant ML projects", "Clear structure"],
  suggestions: ["Add quantifiable metrics to project descriptions", "Include more deep learning keywords if possible"],
};

export const mockSkillGaps = [
  { skill: "Python", current: 85, required: 90, priority: "Low" },
  { skill: "SQL", current: 70, required: 80, priority: "Low" },
  { skill: "Machine Learning", current: 65, required: 85, priority: "Medium" },
  { skill: "Deep Learning", current: 25, required: 70, priority: "High" },
  { skill: "TensorFlow", current: 20, required: 70, priority: "High" },
  { skill: "Statistics", current: 40, required: 60, priority: "Medium" },
  { skill: "Docker", current: 15, required: 50, priority: "Medium" },
];

export const mockRoadmap = [
  { id: 1, title: "Python", status: "Completed", hours: 40, priority: "Low", description: "Master core Python concepts" },
  { id: 2, title: "Machine Learning", status: "Completed", hours: 60, priority: "Medium", description: "Learn fundamental ML algorithms" },
  { id: 3, title: "Statistics", status: "In Progress", hours: 30, priority: "Medium", description: "Probability and statistical modeling" },
  { id: 4, title: "Deep Learning", status: "Not Started", hours: 50, priority: "High", description: "Neural networks and architectures" },
  { id: 5, title: "TensorFlow", status: "Not Started", hours: 40, priority: "High", description: "Build deep learning models" },
  { id: 6, title: "ML Project", status: "Not Started", hours: 60, priority: "High", description: "End-to-end real world project" },
  { id: 7, title: "Resume Optimization", status: "Not Started", hours: 5, priority: "Low", description: "Add keywords and format" },
  { id: 8, title: "Interview Preparation", status: "Not Started", hours: 30, priority: "Medium", description: "Mock interviews and DSA" },
];

export const mockJobRoles = [
  { title: "Machine Learning Engineer", match: 72, description: "Builds and deploys scalable ML models.", requiredSkills: ["Python", "Machine Learning", "Deep Learning", "TensorFlow", "SQL", "Docker"] },
  { title: "Data Scientist", match: 68, description: "Analyzes complex data to extract insights.", requiredSkills: ["Python", "Statistics", "Machine Learning", "Data Visualization", "SQL"] },
  { title: "Data Analyst", match: 85, description: "Processes and performs statistical analysis on data.", requiredSkills: ["SQL", "Excel", "Python", "Tableau", "Statistics"] },
  { title: "Software Developer", match: 60, description: "Develops software applications and systems.", requiredSkills: ["Java/Python", "DSA", "System Design", "Git"] },
  { title: "Frontend Developer", match: 20, description: "Builds user interfaces and web applications.", requiredSkills: ["HTML", "CSS", "JavaScript", "React"] },
  { title: "Backend Developer", match: 45, description: "Builds server-side logic and databases.", requiredSkills: ["Node.js/Python", "SQL", "APIs", "Docker"] },
  { title: "Full Stack Developer", match: 35, description: "Handles both frontend and backend development.", requiredSkills: ["React", "Node.js", "SQL", "Git"] },
  { title: "Cloud Engineer", match: 25, description: "Designs and manages cloud infrastructure.", requiredSkills: ["AWS/Azure", "Docker", "Kubernetes", "Linux"] },
  { title: "Cybersecurity Analyst", match: 15, description: "Protects systems and networks from threats.", requiredSkills: ["Networking", "Linux", "Security Protocols"] },
];

export const mockMySkills = [
  { name: "Python", level: 85 },
  { name: "SQL", level: 70 },
  { name: "Machine Learning", level: 65 },
  { name: "Pandas", level: 80 },
  { name: "Scikit-learn", level: 75 },
  { name: "Deep Learning", level: 25 },
  { name: "TensorFlow", level: 20 },
  { name: "Statistics", level: 40 },
  { name: "Docker", level: 15 },
];

export const mockProjects = [
  { id: 1, title: "Student Performance Prediction", description: "Predicts student performance based on demographic data using regression models.", technologies: ["Python", "Scikit-learn", "Pandas"], status: "Completed", github: "https://github.com" },
  { id: 2, title: "Movie Recommendation System", description: "Collaborative filtering system for movie recommendations.", technologies: ["Python", "Machine Learning", "Numpy"], status: "Completed", github: "https://github.com" },
  { id: 3, title: "Face Mask Detection", description: "Computer vision model to detect face masks in real-time.", technologies: ["Python", "OpenCV", "Deep Learning"], status: "In Progress", github: "https://github.com" },
];

export const mockCertifications = [
  { id: 1, name: "Machine Learning Fundamentals", organization: "Coursera" },
  { id: 2, name: "Python for Data Science", organization: "IBM" },
];
