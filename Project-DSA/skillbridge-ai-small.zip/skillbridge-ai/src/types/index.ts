export type Priority = "High" | "Medium" | "Low";
export type Proficiency = "Beginner" | "Intermediate" | "Advanced" | "Expert";
export type RoadmapStatus = "completed" | "in-progress" | "not-started";
export type ProjectStatus = "Completed" | "In Progress" | "Planned";

export interface Skill {
  id: string;
  name: string;
  category: string;
  proficiency: Proficiency;
  score: number;
}

export interface SkillGap {
  skill: string;
  current: number;
  required: number;
  priority: Priority;
}

export interface RoadmapStep {
  id: string;
  title: string;
  description: string;
  status: RoadmapStatus;
  priority: Priority;
  estimatedHours: number;
}

export interface JobRole {
  id: string;
  title: string;
  category: string;
  match: number;
  avgSalary: string;
  demand: "High" | "Very High" | "Moderate";
  description: string;
  requiredSkills: string[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  status: ProjectStatus;
  githubUrl: string;
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  issuedDate: string;
  credentialUrl: string;
}

export interface ResumeAnalysis {
  atsScore: number;
  detectedSkills: string[];
  missingKeywords: string[];
  strengths: string[];
  improvements: string[];
}

export interface Education {
  degree: string;
  institution: string;
  year: string;
  cgpa: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  location: string;
  targetRole: string;
  bio: string;
  education: Education;
}

export interface ReadinessMetrics {
  overall: number;
  skills: number;
  projects: number;
  resume: number;
  certifications: number;
  roleMatch: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
}
