/**
 * Mock service layer.
 *
 * Every function is async and returns the shape a real FastAPI + MongoDB
 * backend would return, so swapping the mock body for a `fetch()` call to
 * `${API_BASE_URL}/...` is the only change required later.
 */
import {
  mockCertifications,
  mockJobRoles,
  mockProjects,
  mockReadiness,
  mockResumeAnalysis,
  mockRoadmap,
  mockSkillGaps,
  mockSkills,
  mockUser,
  nextSteps,
} from "@/data/mockData";
import type {
  Certification,
  JobRole,
  Project,
  ReadinessMetrics,
  ResumeAnalysis,
  RoadmapStep,
  Skill,
  SkillGap,
  UserProfile,
} from "@/types";

export const API_BASE_URL = "/api";

const delay = <T,>(data: T, ms = 350): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(data), ms));

export const getProfile = (): Promise<UserProfile> => delay(mockUser);
export const updateProfile = (profile: UserProfile): Promise<UserProfile> => delay(profile, 250);

export const getReadiness = (): Promise<ReadinessMetrics> => delay(mockReadiness);
export const getNextSteps = () => delay(nextSteps);

export const getSkills = (): Promise<Skill[]> => delay(mockSkills);
export const getSkillGaps = (): Promise<SkillGap[]> => delay(mockSkillGaps);
export const getRoadmap = (): Promise<RoadmapStep[]> => delay(mockRoadmap);
export const getJobRoles = (): Promise<JobRole[]> => delay(mockJobRoles);
export const getProjects = (): Promise<Project[]> => delay(mockProjects);
export const getCertifications = (): Promise<Certification[]> => delay(mockCertifications);

export const analyzeResume = (file?: File | null): Promise<ResumeAnalysis> => {
  void file;
  return delay(mockResumeAnalysis, 1600);
};
