import { mockReadiness, mockSkillGaps, mockUser } from "@/data/mockData";

export const suggestedQuestions = [
  "What skills am I missing?",
  "What should I learn first?",
  "Suggest a project for me.",
  "How can I improve my resume?",
  "Am I ready for my target role?",
];

const topGaps = mockSkillGaps
  .filter((g) => g.priority !== "Low")
  .sort((a, b) => b.required - b.current - (a.required - a.current))
  .map((g) => g.skill);

function buildAnswer(question: string): string {
  const q = question.toLowerCase();
  const name = mockUser.name.split(" ")[0];

  if (q.includes("missing") || q.includes("gap")) {
    return `${name}, for a ${mockUser.targetRole} role your biggest gaps are **${topGaps
      .slice(0, 3)
      .join(", ")}** and Docker. Deep Learning and TensorFlow are high priority — together they account for most of the 28% you need to reach full role readiness.`;
  }
  if (q.includes("learn first") || q.includes("start") || q.includes("order")) {
    return `Finish **Statistics** first (you're already in progress, ~12 hours left), then move to **Deep Learning** and **TensorFlow**. That order matters: statistics makes neural network training and evaluation far easier to reason about.`;
  }
  if (q.includes("project")) {
    return `Try an **end-to-end image classifier deployed as an API**: train a CNN in TensorFlow, containerize it with Docker and serve predictions over FastAPI. It closes three gaps at once (Deep Learning, TensorFlow, Docker) and looks excellent on a resume.`;
  }
  if (q.includes("resume")) {
    return `Your ATS score is **${mockReadiness.resume}%**. Add the missing keywords (Deep Learning, TensorFlow, Docker, Statistics), quantify each project with accuracy or dataset size, and add a two-line summary targeting ${mockUser.targetRole} roles. That should push you to roughly 88%.`;
  }
  if (q.includes("ready") || q.includes("target role")) {
    return `You're at **${mockReadiness.overall}% career readiness** with a ${mockReadiness.roleMatch}% match for ${mockUser.targetRole}. Strong on Python, projects and data handling; not yet ready on deep learning. Around 8-10 focused weeks on your roadmap should get you to interview-ready.`;
  }
  if (q.includes("hello") || q.includes("hi") || q.includes("hey")) {
    return `Hi ${name}! I'm your SkillBridge AI career assistant. Ask me about your skill gaps, roadmap, projects or resume.`;
  }
  return `Based on your profile (${mockUser.targetRole}, ${mockReadiness.overall}% ready), the highest-impact next move is closing your **Deep Learning** and **TensorFlow** gaps, then shipping one deployed ML project. Ask me about your skills, roadmap, projects or resume for specifics.`;
}

export function askAssistant(question: string): Promise<string> {
  return new Promise((resolve) => setTimeout(() => resolve(buildAnswer(question)), 700));
}
