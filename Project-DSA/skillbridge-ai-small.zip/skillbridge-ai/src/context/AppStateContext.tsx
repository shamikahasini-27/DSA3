import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import {
  mockCertifications,
  mockProjects,
  mockRoadmap,
  mockSkills,
  mockUser,
} from "@/data/mockData";
import type { Certification, Project, RoadmapStatus, RoadmapStep, Skill, UserProfile } from "@/types";

interface AppState {
  profile: UserProfile;
  setProfile: (p: UserProfile) => void;
  skills: Skill[];
  addSkill: (s: Omit<Skill, "id">) => void;
  updateSkill: (s: Skill) => void;
  deleteSkill: (id: string) => void;
  projects: Project[];
  addProject: (p: Omit<Project, "id">) => void;
  deleteProject: (id: string) => void;
  certifications: Certification[];
  addCertification: (c: Omit<Certification, "id">) => void;
  deleteCertification: (id: string) => void;
  roadmap: RoadmapStep[];
  setStepStatus: (id: string, status: RoadmapStatus) => void;
  addRoadmapStep: (step: Omit<RoadmapStep, "id">) => void;
}

const AppStateContext = createContext<AppState | null>(null);

const uid = () => Math.random().toString(36).slice(2, 10);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile>(mockUser);
  const [skills, setSkills] = useState<Skill[]>(mockSkills);
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [certifications, setCertifications] = useState<Certification[]>(mockCertifications);
  const [roadmap, setRoadmap] = useState<RoadmapStep[]>(mockRoadmap);

  const value = useMemo<AppState>(
    () => ({
      profile,
      setProfile,
      skills,
      addSkill: (s) => setSkills((prev) => [...prev, { ...s, id: uid() }]),
      updateSkill: (s) => setSkills((prev) => prev.map((x) => (x.id === s.id ? s : x))),
      deleteSkill: (id) => setSkills((prev) => prev.filter((x) => x.id !== id)),
      projects,
      addProject: (p) => setProjects((prev) => [{ ...p, id: uid() }, ...prev]),
      deleteProject: (id) => setProjects((prev) => prev.filter((x) => x.id !== id)),
      certifications,
      addCertification: (c) => setCertifications((prev) => [{ ...c, id: uid() }, ...prev]),
      deleteCertification: (id) => setCertifications((prev) => prev.filter((x) => x.id !== id)),
      roadmap,
      setStepStatus: (id, status) =>
        setRoadmap((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s))),
      addRoadmapStep: (step) =>
        setRoadmap((prev) =>
          prev.some((s) => s.title === step.title) ? prev : [...prev, { ...step, id: uid() }],
        ),
    }),
    [profile, skills, projects, certifications, roadmap],
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error("useAppState must be used within AppStateProvider");
  return ctx;
}
