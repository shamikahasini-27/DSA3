# SkillBridge AI

Build a modern, polished frontend-only React web app called SkillBridge AI.

Purpose

SkillBridge AI helps students become job-ready by analyzing their skills and resume, identifying skill gaps for a target career, creating a personalized roadmap, and tracking career readiness.

Tech

Use React + Vite + TypeScript + Tailwind CSS + React Router + Lucide icons + Recharts.

Frontend only: no backend, database, authentication server, ML model, or external API. Use centralized realistic mock data and mock service functions. Structure the services so they can later connect to a FastAPI + MongoDB backend.

Design

Create a clean, premium AI/SaaS-style interface:

Light background with blue/purple accents

Rounded cards, subtle shadows, clean typography

Spacious and professional

Responsive on desktop, tablet, and mobile

Simple animations and hover effects

Avoid excessive gradients, colors, or clutter

Brand:
SkillBridge AI
Build Skills. Bridge the Gap. Become Job Ready.

Pages

Public:

Landing

Login

Register

App:

Dashboard

Resume Analyzer

Skill Gap Analysis

Career Roadmap

Job Role Explorer

My Skills

Projects

Certifications

Profile

AI Career Assistant

Landing

Create a professional hero section with the tagline, short description, Get Started and Explore Careers buttons.

Show the workflow:

Profile → AI Analysis → Skill Gaps → Career Roadmap → Job Ready

Add four feature cards:
Skill Gap Analysis, AI Resume Enhancement, Personalized Roadmap, Career Readiness Score.

App Layout

Use a sidebar on desktop and collapsible/mobile navigation on smaller screens.

Sidebar:
Dashboard, Resume Analyzer, Skill Gaps, Career Roadmap, Job Roles, My Skills, Projects, Certifications, Profile.

Include AI Assistant and Logout at the bottom.

Dashboard

Use demo user:

Rahul Kumar
Target: Machine Learning Engineer

Show:

Career Readiness: 72%

Skills: 70%

Projects: 80%

Resume: 78%

Certifications: 60%

Target role match: 72%

Add:

Skill Gap Summary

Roadmap Progress

Recommended Next Steps

Simple charts/progress indicators

Top skill gaps:

Deep Learning — High

TensorFlow — High

Statistics — Medium

Docker — Medium

Resume Analyzer

Create PDF drag/drop upload UI with mock analysis.

Show:

ATS Score: 78%

Detected skills

Missing keywords

Resume strengths

Resume improvements

Detected:
Python, SQL, Machine Learning, Pandas, NumPy, Scikit-learn

Missing:
Deep Learning, TensorFlow, Docker, Statistics

Include an Improve Resume button.

Skill Gap Analysis

Target: Machine Learning Engineer.

Compare current vs required levels for:
Python, SQL, Machine Learning, Deep Learning, TensorFlow, Statistics, Docker.

Use progress bars and priority badges.

Include Add to Roadmap and Generate Roadmap actions.

Career Roadmap

Create a visual vertical timeline:

Python ✓
→ Machine Learning ✓
→ Statistics
→ Deep Learning
→ TensorFlow
→ ML Project
→ Resume Optimization
→ Interview Preparation

Each step has status, priority, estimated hours and description.

Allow changing status using frontend state.

Job Role Explorer

Create searchable/filterable role cards for:
Machine Learning Engineer, Data Scientist, Data Analyst, Software Developer, Frontend Developer, Backend Developer, Full Stack Developer, Cloud Engineer, Cybersecurity Analyst.

Show match percentage and required skills.

My Skills

Display skill cards with:
name, category, proficiency, score.

Demo skills:
Python 85%, SQL 70%, Machine Learning 65%, Pandas 80%, Scikit-learn 75%, Deep Learning 25%, TensorFlow 20%, Statistics 40%, Docker 15%.

Allow add/edit/delete using mock frontend state.

Projects

Create project cards and an Add Project modal.

Demo projects:

Student Performance Prediction

Movie Recommendation System

Face Mask Detection

Show technologies, status and GitHub link.

Certifications

Create certification cards and Add Certification modal.

Demo:
Machine Learning Fundamentals — Coursera
Python for Data Science

Profile

Show/edit:
personal information, education, career goal, skills, projects and certifications.

AI Career Assistant

Add a floating AI assistant button throughout the app.

Create a modern chat panel with mock responses.

Suggested questions:

What skills am I missing?

What should I learn first?

Suggest a project for me.

How can I improve my resume?

Am I ready for my target role?

Use the user's mock profile context when generating responses.

Architecture

Keep mock data in:

src/data/

Keep API-ready mock functions in:

src/services/

Use reusable components for cards, progress bars, skill badges, roadmap steps, modals, resume upload and AI chat.

Use TypeScript interfaces/types.

Quality

Before finishing:

Ensure every route works.

Ensure navigation works.

Ensure buttons have appropriate interactions.

Ensure forms work with frontend validation.

Ensure responsive layouts work.

Ensure there are no broken imports, TypeScript errors or console errors.

Do not leave blank or unfinished pages.

Keep the implementation simple and backend-ready.

The final result should look like a real professional AI career platform, while remaining simple enough for a college ML project.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4c2c710d-1b1f-432a-8237-4ecd4427c88f).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
